const Axios = require('Axios');
const { BlobServiceClient } = require("@azure/storage-blob");
const CosmosClient = require("@azure/cosmos").CosmosClient;

module.exports = async function (context, req) {
    var res = {
        status: 200,
        body: {
            sucess: true,
            message: []
        }
    }
    var configFileParams = {
        "stage": process.env["lambda_profile"],
        "mySQL_server": process.env["mySqlServerName"],
        "db_port": 3306,
        "mySQL_db_user": process.env["mySqlUsername"],
        "admin_login_password": process.env["mySqlPwd"],
        "db_name": process.env["mySqlDatabaseName"],
        "etl_queue": process.env["etl_job_process_queue"],
        "cs_queue": process.env["contentsync_job_process_queue"],
        "strg_name": process.env["storage_accountname"],
        "strg_key": process.env["storage_accountkey"],
        "cosmos_name": process.env["cosmos_accountname"],
        "cosmos_primary_key": process.env["cosmos_accesskey"],
        "cosmos_db_name": process.env["cosmos_csdbname"],
        "servicebus_name": process.env["servicebus_namespace"],
        "storageAccountConnectionString": process.env["WEBSITE_CONTENTAZUREFILECONNECTIONSTRING"],
        "applicationConfigBucket": process.env["applicationConfigBucket"],
        "cosmos_tenant_container": process.env["cosmos_tenant_container"],
        "clientBaseUrl": process.env["etl_api_url"],
        "secretKey": process.env["Prosperoware_encryptedKey"],
        "clientSecret": process.env["Prosperoware_secretKey"],
        "tenantId": process.env["Prosperoware_tenantId"],
        "id": process.env["Prosperoware_tenantId"],
        "features": process.env["product_features"]
    };
    res = await ensureStorageBlobStructure(configFileParams, res);
    res = await ensureCosmosData(configFileParams, res);
    if (configFileParams.features != 'Content Sync') {
        res = await updateDatabaseSchema(configFileParams, res);
    }
    else {
        res.body.message.push('Database schema update is skipped for Content Sync feature only');
    }
    if(!res.body.sucess){
        res.status = 400;
    }
    context.res = res;
    context.done();
}

async function ensureStorageBlobStructure(configFileParams, result){
    result = await ensureFile(
        `ymls\\appconfig-${configFileParams.stage}.yml`,
        'https://raw.githubusercontent.com/Prosperoware/cam-azure-deployment/master/application-config/ymls/appconfig-%5Bstage%5D.yml',
        configFileParams.storageAccountConnectionString,
        configFileParams.applicationConfigBucket,
        result,
        configFileParams);
    if(!result.body.sucess)
        return result;
    result = await ensureFile(
        `errors\\errors-${configFileParams.stage}.properties`,
        'https://raw.githubusercontent.com/Prosperoware/cam-azure-deployment/master/application-config/errors/errors-%5Bstage%5D.properties',
        configFileParams.storageAccountConnectionString,
        configFileParams.applicationConfigBucket,
        result);
    return result;
}

async function ensureFile(currentPath, fileUrl, storageAccountConnectionString, applicationConfigBucket, res, placeholders){
    try {
        const blobServiceClient = new BlobServiceClient.fromConnectionString(storageAccountConnectionString);
        const containerClient = blobServiceClient.getContainerClient(applicationConfigBucket);
        const containerExists =  await containerClient.exists();
        if(!containerExists) {
            res.body.sucess = false;
            res.body.message.push(`The container ${applicationConfigBucket} does not exist.`);
        }
        const blockBlobClient = containerClient.getBlockBlobClient(currentPath);
        const fileExists = await blockBlobClient.exists();
        if(fileExists){
            res.body.message.push(`${currentPath} file already exists.`);
            return res;
        }

        return Axios({
            method: 'get',
            url: fileUrl
        }).then(async response => {
            var data = response.data;
            if(placeholders){
                data = formatString(response.data, placeholders);
            }
            const uploadBlobResponse = await blockBlobClient.upload(data, data.length);
            res.body.message.push(`${currentPath} file was created successfully`);
            return res;
        });
    }
    catch(err){
        res.body.sucess = false;
        res.body.message.push(err);
        return res;
    }
}

function formatString(s, placeholders){
    for(var propertyName in placeholders) {
        var re = new RegExp('\\[' + propertyName + '\\]', 'gm');
        s = s.replace(re, placeholders[propertyName]);
    }    
    return s;
}

function applyIfExists(obj, config) {
    var property;
    if (obj) {
        for (property in config) {
            if (obj[property]) {
                obj[property] = config[property];
            }
        }
    }
    return obj;
}

async function ensureCosmosData(configFileParams,  res) {
    try
    {
        const endpoint = `https://${configFileParams.cosmos_name}.documents.azure.com:443/`;
        const key = configFileParams.cosmos_primary_key;
        const client = new CosmosClient({ endpoint, key });
        const database = await client.database(configFileParams.cosmos_db_name);
        const container = await database.container(configFileParams.cosmos_tenant_container);
        const querySpec = {
            query: "SELECT * FROM c WHERE c.tenantId=@tenantId",
            parameters: [{
                    name: "@tenantId",
                    value: configFileParams.tenantId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        if(resources && resources.length > 0){
            res.body.message.push('Tenant recod already exists');
        }
        else {
            var fileUrl = 'https://raw.githubusercontent.com/Prosperoware/cam-azure-deployment/master/contentsync-tenant.json';
            return Axios({
                method: 'get',
                url: fileUrl
            }).then(async response => {
                var data = applyIfExists(response.data, configFileParams);
                const { resource: createdItem } = await container.items.create(data);
                res.body.message.push('A record was added to the tenant container');
                return res;
            });
        }
        return res;
    }
    catch(err){
        res.body.sucess = false;
        res.body.message.push(err.message);
        return res;
    }
}

async function updateDatabaseSchema(configFileParams,  res){
    try{
        var authUrl = `https://${configFileParams.clientBaseUrl}/api/v1/dms/content-sync/auth/token`;
        var schemaUrl = `https://${configFileParams.clientBaseUrl}/api/v1/dms/content-sync/liquibase/execute`;
        return Axios({
            method: 'post',
            url: authUrl,
            headers: { 
                'Content-Type': 'application/json'
            },
            data : {
                "tenantId": configFileParams.tenantId,
                "secretKey": configFileParams.clientSecret
            }
        }).then(async response => {
            var d = response.data;
            if(d.status && d.status == 'success' && d.data){
                try {
                    return Axios({
                        method: 'get',
                        url: schemaUrl,
                        headers: {
                            "cs-auth-token": d.data
                        }
                    }).then(async response2 => {
                        if(response2.data.status == 'success'){
                            res.body.message.push('database schema updated successfully!');
                        }
                        else {
                            res.body.message.push(response2.data);
                        }
                        return res;
                    });
                }
                catch{
                    return res;
                }
            }
            else if(d.error && d.error.message){
                res.body.message.push(d.error.message);
            }
            return res;
        });
        return res;
    }
    catch(err){
        res.body.sucess = false;
        res.body.message.push(err.message);
        return res;
    }
}
