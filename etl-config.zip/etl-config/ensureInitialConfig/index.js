const Axios = require('Axios');
const { BlobServiceClient, StorageSharedKeyCredential } = require("@azure/storage-blob");

module.exports = async function (context, req) {
    var res = {
        status: 200,
        body: {
            sucess: true,
            message: "sucess"
        }
    }
    var configFileParams = {
        "stage": process.env["lambda_profile"],
        "mySQL_server": process.env["mySqlServerName"],
        "db_port": 3306,
        "mySQL_db_user": process.env["mySqlUsername"],
        "admin_login_password": process.env["mySqlPwd"],
        "db_name": process.env["mySqlDatabaseName"],
        "etl_queue": process.env["etl_job_process_queue"],
        "strg_name": process.env["storage_accountname"],
        "strg_key": 'j38+IzAfMe2Zc12AraqXGp+GRGYHvIeoQ721IamD/uJR4Ovf9WMikJ06e0rrG5xc9iitMzdm5JhT8/g5xGGaGQ==', //process.env["storage_accountkey"],
        "cosmos_name": process.env["cosmos_accountname"],
        "cosmos_primary_key": process.env["cosmos_accesskey"],
        "cosmos_db_name": process.env["cosmos_csdbname"],
        "servicebus_name": process.env["servicebus_namespace"]
    };
    var res = await ensureStorageBlobStructure(configFileParams, res);
    context.res = res;
    context.done();
}

async function ensureStorageBlobStructure(configFileParams, result){
    try {
        result.body.message = await ensureFile(
            `ymls\\appconfig-${configFileParams.stage}.yml`,
             'https://raw.githubusercontent.com/Prosperoware/cam-azure-deployment/master/application-config/ymls/appconfig-%5Bstage%5D.yml',
             configFileParams.strg_name,
             configFileParams.strg_key,
             configFileParams);
    }
    catch(err){
        result.body.sucess = false;
        result.status = 400;
        result.body.message = err;
    }
    return result;
}

function ensureFile(currentPath, fileUrl, storageAccountName, storageAccountKey, placeholders){
    /*const sharedKeyCredential = new StorageSharedKeyCredential(storageAccountName, sorageAccountKey);
    const blobServiceClient = new BlobServiceClient(
        `https://${storageAccountName}.blob.core.windows.net`,
        sharedKeyCredential
    );*/
    return Axios({
        method: 'get',
        url: fileUrl
    }).then(response => {
        var data = response.data;
        if(placeholders){
            data = formatString(response.data, placeholders);
        }
        return data;
    });
}

function formatString(s, placeholders){
    for(var propertyName in placeholders) {
        var re = new RegExp('{' + propertyName + '}', 'gm');
        s = s.replace(re, placeholders[propertyName]);
    }    
    return s;
}


